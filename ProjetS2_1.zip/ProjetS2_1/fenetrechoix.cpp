#include "fenetrechoix.h"

FenetreChoix::FenetreChoix()
{

}
