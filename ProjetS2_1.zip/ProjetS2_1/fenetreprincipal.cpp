#include "fenetreprincipal.h"
#include "ui_fenetreprincipal.h"

FenetrePrincipal::FenetrePrincipal(QWidget *parent) :
    QMainWindow(parent)
{

}

FenetrePrincipal::~FenetrePrincipal()
{

}
