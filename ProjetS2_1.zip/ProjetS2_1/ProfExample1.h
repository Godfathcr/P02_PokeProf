#pragma once
#include "Prof.h"
class ProfExample1 :
	public Prof
{
public:
	ProfExample1();
	~ProfExample1();
};

