#ifndef FENETREOPTION_H
#define FENETREOPTION_H

#include <QWidget>

class FenetreOption: public QWidget
{
    Q_OBJECT
public:
    FenetreOption();
};

#endif // FENETREOPTION_H
