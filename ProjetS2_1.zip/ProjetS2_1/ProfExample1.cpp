#include "ProfExample1.h"



ProfExample1::ProfExample1()
{
}


ProfExample1::~ProfExample1()
{
}
