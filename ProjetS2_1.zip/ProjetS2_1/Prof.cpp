#include "Prof.h"



Prof::Prof()
{
}


Prof::~Prof()
{
}
