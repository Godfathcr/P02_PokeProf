#include "fenetrecombat.h"

FenetreCombat::FenetreCombat()
{

}
