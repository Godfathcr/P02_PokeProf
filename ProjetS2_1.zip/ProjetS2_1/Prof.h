#pragma once
class Prof
{
public:
	Prof();
	virtual ~Prof();
};

