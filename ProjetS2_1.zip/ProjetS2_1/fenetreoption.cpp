#include "fenetreoption.h"

FenetreOption::FenetreOption()
{

}
