#pragma once
#include "Sort.h"
class SortExample1 :
	public Sort
{
private:

public:
	SortExample1();
	~SortExample1();
};

