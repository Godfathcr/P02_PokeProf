#pragma once
class Sort
{
public:
	Sort();
	virtual ~Sort();
};

