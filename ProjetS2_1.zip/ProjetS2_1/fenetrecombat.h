#ifndef FENETRECOMBAT_H
#define FENETRECOMBAT_H

#include <QWidget>

class FenetreCombat: public QWidget
{
    Q_OBJECT
public:
    FenetreCombat();
};

#endif // FENETRECOMBAT_H
