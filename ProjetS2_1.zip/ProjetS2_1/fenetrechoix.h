#ifndef FENETRECHOIX_H
#define FENETRECHOIX_H

#include <QWidget>

class FenetreChoix: public QWidget
{
    Q_OBJECT
public:
    FenetreChoix();
};

#endif // FENETRECHOIX_H
